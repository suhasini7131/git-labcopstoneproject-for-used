package com.stackroute.slot.exceptions;

public class SlotDoesNotExists extends Exception{
}
