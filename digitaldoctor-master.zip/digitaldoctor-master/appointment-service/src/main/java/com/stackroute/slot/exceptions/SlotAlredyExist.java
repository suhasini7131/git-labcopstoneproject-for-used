package com.stackroute.slot.exceptions;

public class SlotAlredyExist extends Exception{

    public SlotAlredyExist(String message){
        super(message);
    }

}
