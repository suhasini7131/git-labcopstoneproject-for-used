package com.stackroute.appointment.models;

public enum AppointmentStatus {
    UPCOMING,
    PAST,
    CANCELLED
}
