package com.stackroute.slot.models;

public enum SlotStatus {

    AVAILABLE,
    BOOKED
}
