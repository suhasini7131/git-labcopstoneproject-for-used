package com.stackroute.service;

import com.stackroute.model.EmailDetails;


public interface EmailService {

    void sendEmail(EmailDetails details);


}
