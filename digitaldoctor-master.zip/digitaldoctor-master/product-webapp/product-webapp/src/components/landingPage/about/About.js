import React from 'react';

const About = () => {

    return (
        <div>hi About</div>

    );
}

export default About;
