import React from 'react';

const Contact = () => {

    return (
        <div>hi Contact</div>

    );
}

export default Contact;
