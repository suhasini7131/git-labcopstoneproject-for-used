package com.stackroute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductWebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductWebappApplication.class, args);
	}

}
