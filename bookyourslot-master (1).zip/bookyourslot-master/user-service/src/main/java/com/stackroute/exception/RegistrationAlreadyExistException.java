package com.stackroute.exception;

public class RegistrationAlreadyExistException extends RuntimeException{
    public RegistrationAlreadyExistException(String message) {
        super(message);
    }}
