package com.stackroute.exception;

public class InterviewSlotAlreadyExistException extends RuntimeException{
    public InterviewSlotAlreadyExistException(String message) {
        super(message);
    }}

