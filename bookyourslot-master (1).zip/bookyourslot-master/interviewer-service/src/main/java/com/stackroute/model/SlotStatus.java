package com.stackroute.model;

public enum SlotStatus {
        UNAVAILABLE,AVAILABLE,CANCELLED,COMPLETED
}
