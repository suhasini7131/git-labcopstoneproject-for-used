package com.stackroute.model;

public enum SlotStatus {
    BOOKED,AVAILABLE,UNAVAILABLE,CANCELLED,COMPLETED;
}
