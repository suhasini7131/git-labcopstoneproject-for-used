package com.stackroute.model;

public enum UserRole {

    INTERVIEWER,TAGTEAM;
}
