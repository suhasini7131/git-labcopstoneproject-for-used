// package com.stackroute.service;

// import com.stackroute.exception.UserNotFoundException;
// import com.stackroute.model.User;
// import com.stackroute.userDto.UserDto;

// public interface UserService {
//     User saveUser(User user);
//     User findByEmailAndPassword(String email , String password) throws UserNotFoundException;

//     UserDto getUsers(UserDto userDto);
// }
