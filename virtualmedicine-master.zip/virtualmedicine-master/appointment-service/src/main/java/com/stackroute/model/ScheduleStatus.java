package com.stackroute.model;

public enum ScheduleStatus {
    AVAILABLE,BOOKED,NOT_AVAILABLE;
}
