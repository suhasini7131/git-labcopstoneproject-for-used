package com.stackroute.exception;

public class ScheduleIdNotNullException extends Exception{

    public ScheduleIdNotNullException(String message){
        super(message);
    }
}
