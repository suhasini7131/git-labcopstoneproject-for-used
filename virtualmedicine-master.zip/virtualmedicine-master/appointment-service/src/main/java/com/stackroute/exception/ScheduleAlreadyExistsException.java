package com.stackroute.exception;

public class ScheduleAlreadyExistsException extends Exception{



    public ScheduleAlreadyExistsException(String message) {
        super(message);
    }
}
