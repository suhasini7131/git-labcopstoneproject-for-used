package com.stackroute.exception;

public class ScheduleNotFoundException extends Exception{

   
    public ScheduleNotFoundException(String message) {
        super(message);
    }
}
