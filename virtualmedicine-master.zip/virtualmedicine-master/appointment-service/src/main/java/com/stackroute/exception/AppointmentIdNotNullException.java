package com.stackroute.exception;

public class AppointmentIdNotNullException extends Exception{

    public AppointmentIdNotNullException(String message){
        super(message);
    }
}
