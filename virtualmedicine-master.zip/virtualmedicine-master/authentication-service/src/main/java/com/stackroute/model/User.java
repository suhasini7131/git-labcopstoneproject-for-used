package com.stackroute.model;

public interface User {
     String getEmail();
     String getPassword();
}
