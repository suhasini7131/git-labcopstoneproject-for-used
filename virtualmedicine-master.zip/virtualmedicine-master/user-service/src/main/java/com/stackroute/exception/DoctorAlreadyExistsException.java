package com.stackroute.exception;

public class DoctorAlreadyExistsException extends RuntimeException{


    public DoctorAlreadyExistsException(String message) {
        super(message);
    }
}
