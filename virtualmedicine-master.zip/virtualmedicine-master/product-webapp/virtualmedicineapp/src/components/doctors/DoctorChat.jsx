import React from "react";

function DoctorChat() {
  return (
    <>
      <div className="col-9">
        <h1 style={{ textAlign: "center" }}>Doctor Chat Section</h1>
      </div>
    </>
  );
}

export default DoctorChat;
