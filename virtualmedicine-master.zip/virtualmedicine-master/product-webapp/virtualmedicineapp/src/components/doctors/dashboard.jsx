import React from "react";

function Dashboard() {
  return (
    <>
      <div className="col-9">
        <h1 style={{ textAlign: "center" }}>
          Welcome To Doctor Dashboard Page
        </h1>
      </div>
    </>
  );
}

export default Dashboard;
