import React from "react";

function ChangeDoctorPassword() {
  return (
    <>
      <div className="col-9">
        <h1 style={{ textAlign: "center" }}>Change Password</h1>
      </div>
    </>
  );
}

export default ChangeDoctorPassword;
