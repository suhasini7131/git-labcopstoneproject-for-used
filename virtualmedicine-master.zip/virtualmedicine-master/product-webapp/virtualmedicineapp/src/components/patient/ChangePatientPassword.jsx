import React from "react";

function ChangePatientPassword() {
  return <div>ChangePatientPassword</div>;
}

export default ChangePatientPassword;
