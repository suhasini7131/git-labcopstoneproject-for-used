import React from "react";

function PatientDashboard() {
  return <div>Patient Dashboard</div>;
}

export default PatientDashboard;
