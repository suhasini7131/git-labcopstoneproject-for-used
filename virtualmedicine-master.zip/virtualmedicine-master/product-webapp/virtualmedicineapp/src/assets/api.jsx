const Api = {
  api: "http://localhost:8060",
};

export default Api;
