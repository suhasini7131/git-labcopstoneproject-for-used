export const header =
  [
    {
      "userEmailId": "sarath@gmail.com",
      "password": "User@1234",
      "userRole": "TAG"
    },
    {
      "userEmailId": "user123@gmail.com",
      "password": "User@12345",
      "userRole": "INTERVIEWER"
    }
  ]