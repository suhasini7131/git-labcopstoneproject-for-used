export const DEMO_CREDENTIALS = {
  username: 'sarath',
  email: 'sarath@gmail.com',
  password:'Sarath@121779',
  phone:'9595959595'
}
