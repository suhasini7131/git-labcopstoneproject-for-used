export const DEMO_CREDENTIALS = {
  username: 'sarath',
  password: 'Sarath@1234',
}