import React from 'react'

export const error500 = (props) => {
  return (
    <div>error500</div>
  )
}
