import React from 'react'

export const Error404 = (props) => {
  return (
    <div className="">
      <h1>404</h1>
      <h1>The Page you are looking is not found...</h1>
    </div>
  )
}
