package com.stackroute.tagservice.enums;

public enum BookedStatus {
    UPCOMING, BOOKED, CANCELED, PAST ;
}
