package com.stackroute.userservice.enums;

public enum UserRole {
    TAG, INTERVIEWER;
}
