package com.stackroute.authenticationservice.enums;

public enum UserRole {
     TAG,INTERVIEWER;
}
