package com.stackroute.interviewerservice.enums;
//This is enum to declare the booked status
public enum BookedStatus {
    UPCOMING, PAST, CANCELED, AVAILABLE, UNAVAILABLE,BOOKED
}
