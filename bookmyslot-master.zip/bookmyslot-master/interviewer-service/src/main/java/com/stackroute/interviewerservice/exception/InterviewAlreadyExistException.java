package com.stackroute.interviewerservice.exception;

public class InterviewAlreadyExistException extends RuntimeException{
    public InterviewAlreadyExistException(String message) {
        super(message);
    }}
