package com.stackroute.exception;

public class EnthusiastNotFoundException extends Exception{
}
