package com.stackroute.exception;

public class ExpertNotFoundException extends Exception{
}
