package com.stackroute.exception;

public class EnthusiastAlreadyExistsException extends Exception{

    public EnthusiastAlreadyExistsException(String message) {
        super(message);
    }
}
