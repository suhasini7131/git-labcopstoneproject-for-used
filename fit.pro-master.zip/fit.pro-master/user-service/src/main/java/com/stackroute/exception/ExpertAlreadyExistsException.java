package com.stackroute.exception;

public class ExpertAlreadyExistsException extends Exception {

    public ExpertAlreadyExistsException(String message) {
        super(message);
    }
}
