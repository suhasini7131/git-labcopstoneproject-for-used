package com.stackroute.model;

public enum AppointmentStatus {
    BOOKED, CANCELED
}
