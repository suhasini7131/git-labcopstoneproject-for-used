package com.stackroute.slot.model;

public enum Status {
    BOOKED, AVAILABLE
}
