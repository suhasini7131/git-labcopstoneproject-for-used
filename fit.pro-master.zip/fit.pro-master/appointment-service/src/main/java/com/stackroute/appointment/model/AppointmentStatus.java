package com.stackroute.appointment.model;

public enum AppointmentStatus {
    BOOKED, CANCELED
}
