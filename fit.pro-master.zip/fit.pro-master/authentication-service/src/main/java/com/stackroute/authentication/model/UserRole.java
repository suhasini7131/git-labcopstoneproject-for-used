package com.stackroute.authentication.model;

public enum UserRole {
    ENTHUSIAST,EXPERT
}
