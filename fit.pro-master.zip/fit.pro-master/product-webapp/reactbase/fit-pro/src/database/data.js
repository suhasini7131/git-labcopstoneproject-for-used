export default {
    "private" : 8967532412,
    "user": {
        'id':  1,
        'firstname': "Aakash",
        'lastname': "Kumar",
        'email': "",
        'phone': 8967532412,
    },
    'appointments': [
        {
            'id': 1,
            'fullname': "Komal Kham", 
            'email': "komalkhan007@gmail.com",
            'phone': 1987654321,
            'experience': "5",
            'education': 'MBA',
            'specialization': 'phychotherapist',
            'aboutme': 'Hi, I am a doctor'
        },
        {
            id: 2,
            'fullname': "Abhinav Sukla", 
            'email': "Asukla07@gmail.com",
            'phone': 1234567890,
            'experience': "4",
            'education': 'MBA',
            'specialization': 'engineer',
            'aboutme': 'Hi, I am an engineer'
        },
        {
            id: 3,
            'fullname': "Alis pandit", 
            'email': "Asukla07@gmail.com",
            'phone': 1234567890,
            'experience': "4",
            'education': 'MBA',
            'specialization': 'engineer',
            'aboutme': 'Hi, I am an engineer'
        }
    ]
}
