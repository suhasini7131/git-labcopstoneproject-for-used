import React from 'react'

export default function specialization() {
  return (
    <div>specialization</div>
  )
}
