package com.stackroute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestExecutionListeners;

@SpringBootTest
@TestExecutionListeners
class UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
