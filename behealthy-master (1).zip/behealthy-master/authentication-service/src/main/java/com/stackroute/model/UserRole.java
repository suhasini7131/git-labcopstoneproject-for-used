package com.stackroute.model;

public enum UserRole {
    PATIENT,DOCTOR
}
