package com.stackroute.model;

public enum Gender {
    MALE, FEMALE, OTHER;
}
