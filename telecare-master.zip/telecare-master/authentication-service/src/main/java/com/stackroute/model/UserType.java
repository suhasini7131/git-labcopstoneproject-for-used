package com.stackroute.model;

public enum UserType {
    PATIENT,
    DOCTOR;
    /*PATIENT_ROLE("PATIENT_ROLE"),
    DOCTOR_ROLE("DOCTOR_ROLE");

    private final String userRole;
    UserType(String s)
    {
        this.userRole=s;
    }

    public String toString() {
        return this.userRole;
    }*/


}
