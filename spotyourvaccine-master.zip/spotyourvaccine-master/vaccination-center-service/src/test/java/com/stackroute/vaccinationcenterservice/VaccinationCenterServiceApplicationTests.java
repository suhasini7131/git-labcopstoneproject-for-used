package com.stackroute.vaccinationcenterservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinationCenterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
