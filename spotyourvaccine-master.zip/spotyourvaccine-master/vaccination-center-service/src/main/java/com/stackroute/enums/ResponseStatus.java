package com.stackroute.enums;

/**
 * Enum to Define {@link ResponseStatus}
 *
 * @author Jitender <Jitender.1@globallogic.com>
 */
public enum ResponseStatus {
    SUCCESS,ERROR,
}
