package com.stackroute.enums;

/**
 * Enum to Define Slot Status
 *
 * @author Jitender <Jitender.1@globallogic.com>
 */
public enum SlotStatus {
    BOOKED,AVAILABLE,EXPIRED
}
