package com.stackroute.enums;

/**
 * Enum to define vaccine type
 *
 * @author Jitender <Jitender.1@globallogic.com>
 */
public enum VaccineType{
	COVISHIELD, COVAXIN;

}
