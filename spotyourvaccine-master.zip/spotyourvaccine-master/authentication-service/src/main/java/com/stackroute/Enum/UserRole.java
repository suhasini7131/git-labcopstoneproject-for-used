package com.stackroute.Enum;

public enum UserRole {
    USER,CENTER

}
