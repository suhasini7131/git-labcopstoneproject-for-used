package com.stackroute.enums;

public enum UserRole {

    USER,CENTER
}
