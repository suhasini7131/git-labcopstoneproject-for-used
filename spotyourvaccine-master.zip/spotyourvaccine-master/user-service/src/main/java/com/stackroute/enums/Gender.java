package com.stackroute.enums;

public enum Gender {
    MALE,FEMALE,TRANSGENDER,

}
