package com.stackroute.enums;

public enum Status {

    BOOKED,AVAILABLE,EXPIRED
}
