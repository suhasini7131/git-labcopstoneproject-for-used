package com.stackroute.enums;

public enum Vaccine {
    COVISHIELD,COVAXIN
}
